import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/audio.dart';
import '../core/game_theme.dart';
import '../game/characters.dart' as roster;
import '../widgets/avatar.dart';
import '../widgets/character_card_panel.dart';

/// ---------------------------------------------------------------------------
/// Characters screen — full redesign to match the reference screenshots:
/// a 3-zone landscape layout —
///   1) LEFT: a big hero showcase of the currently-highlighted character,
///      standing full-body with its name tag underneath.
///   2) MIDDLE: a "Select Character" panel holding a scrollable grid of
///      square slot cards for every character in the active category —
///      tapping one both highlights it in the hero panel on the left AND
///      equips it immediately.
///   3) RIGHT: a vertical "Characters" category sidebar with 7 tabs
///      (Gaming / Anime / Donghua / Marvels / K-pop / Politicians / Banner).
///      The selected tab gets the gold treatment, unselected tabs are a
///      flat light panel, and a red circular close (X) button sits above
///      the tab list to leave the screen.
/// ---------------------------------------------------------------------------
class CharactersScreen extends StatefulWidget {
  const CharactersScreen({super.key, required this.selected});

  final String selected;

  @override
  State<CharactersScreen> createState() => _CharactersScreenState();
}

class _CharactersScreenState extends State<CharactersScreen> {
  late String _selected = widget.selected;

  /// The category tab currently showing in the middle grid. Starts on
  /// whichever category the player's current character belongs to so the
  /// screen opens already scrolled to the right rail.
  late roster.CharacterCategory _category = roster.Characters.categoryOf(
    widget.selected,
  );

  /// Which character is highlighted in the big hero panel on the left —
  /// defaults to the equipped character, but tapping any slot (even without
  /// equipping) could preview it; here we simply keep it in lock-step with
  /// the equipped pick for simplicity and instant feedback.
  String get _hero => _selected;

  Future<void> _pick(String name) async {
    Sfx.instance.uiClick();
    setState(() => _selected = name);
    final p = await SharedPreferences.getInstance();
    await p.setString('character', name);
  }

  void _selectCategory(roster.CharacterCategory c) {
    if (c == _category) return;
    Sfx.instance.uiClick();
    setState(() => _category = c);
  }

  void _back() {
    Sfx.instance.uiClick();
    Navigator.of(context).pop(_selected);
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        Navigator.of(context).pop(_selected);
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF14171F),
        body: DecoratedBox(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF1C2030), Color(0xFF11131B)],
            ),
          ),
          child: SafeArea(
            child: LayoutBuilder(
              builder: (context, cts) {
                final w = cts.maxWidth;
                final h = cts.maxHeight;
                final scale = (h / 420.0).clamp(0.62, 1.3);

                return Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // ---------------- LEFT: hero showcase ----------------
                    SizedBox(
                      width: w * 0.30,
                      child: _HeroShowcase(character: _hero, scale: scale),
                    ),

                    // ---------------- MIDDLE: select-character panel ------
                    Expanded(
                      child: Padding(
                        padding: EdgeInsets.fromLTRB(
                          6 * scale,
                          12 * scale,
                          6 * scale,
                          12 * scale,
                        ),
                        child: _SelectGridPanel(
                          category: _category,
                          selected: _selected,
                          scale: scale,
                          onTap: _pick,
                        ),
                      ),
                    ),

                    // ---------------- RIGHT: category sidebar -------------
                    SizedBox(
                      width: w * 0.165,
                      child: _CategorySidebar(
                        category: _category,
                        scale: scale,
                        onSelect: _selectCategory,
                        onClose: _back,
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}

// =============================================================================
// LEFT ZONE — big hero portrait of the currently-equipped character + name
// plate, standing on a softly lit circular platform.
// =============================================================================
class _HeroShowcase extends StatelessWidget {
  const _HeroShowcase({required this.character, required this.scale});

  final String character;
  final double scale;

  @override
  Widget build(BuildContext context) {
    final c = roster.Characters.byName(character);
    return Padding(
      padding: EdgeInsets.fromLTRB(10 * scale, 10 * scale, 4 * scale, 10 * scale),
      child: Column(
        children: [
          Expanded(
            child: Stack(
              alignment: Alignment.bottomCenter,
              children: [
                // soft radial platform glow
                Positioned(
                  bottom: 6 * scale,
                  child: Container(
                    width: 140 * scale,
                    height: 34 * scale,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        colors: [
                          GameColors.gold.withValues(alpha: 0.35),
                          GameColors.gold.withValues(alpha: 0.0),
                        ],
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(bottom: 14 * scale),
                  child: CharacterBlend(
                    character: character,
                    alignment: Alignment.bottomCenter,
                    widthFactor: 1.5,
                    fallbackSeed: character.codeUnits.fold(0, (a, b) => a + b),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 6 * scale),
          // name plate
          Container(
            padding: EdgeInsets.symmetric(
              horizontal: 18 * scale,
              vertical: 7 * scale,
            ),
            decoration: BoxDecoration(
              gradient: GameGradients.goldRim,
              borderRadius: BorderRadius.circular(14 * scale),
              boxShadow: GameShadows.raised,
            ),
            child: Text(
              c.name.toUpperCase(),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 15 * scale,
                fontWeight: FontWeight.w900,
                color: const Color(0xFF231708),
                letterSpacing: 0.6,
              ),
            ),
          ),
          SizedBox(height: 4 * scale),
          Text(
            c.category == roster.CharacterCategory.anime
                ? 'ANIME'
                : 'GAMING',
            style: TextStyle(
              fontSize: 10.5 * scale,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.6,
              color: Colors.white54,
            ),
          ),
        ],
      ),
    );
  }
}

// =============================================================================
// MIDDLE ZONE — "Select Character" panel: heading + scrollable grid of
// square slot cards for the active category.
// =============================================================================
class _SelectGridPanel extends StatelessWidget {
  const _SelectGridPanel({
    required this.category,
    required this.selected,
    required this.scale,
    required this.onTap,
  });

  final roster.CharacterCategory category;
  final String selected;
  final double scale;
  final ValueChanged<String> onTap;

  @override
  Widget build(BuildContext context) {
    final list = roster.Characters.byCategory(category);

    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1B1F2B),
        borderRadius: BorderRadius.circular(18 * scale),
        border: Border.all(color: Colors.white.withValues(alpha: 0.08)),
        boxShadow: GameShadows.panel,
      ),
      child: Column(
        children: [
          Padding(
            padding: EdgeInsets.fromLTRB(
              16 * scale,
              12 * scale,
              16 * scale,
              6 * scale,
            ),
            child: Row(
              children: [
                Text(
                  'Select Character',
                  style: TextStyle(
                    fontSize: 15 * scale,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    letterSpacing: 0.3,
                  ),
                ),
                const Spacer(),
                Text(
                  '${list.length} available',
                  style: TextStyle(
                    fontSize: 10.5 * scale,
                    fontWeight: FontWeight.w700,
                    color: Colors.white38,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: list.isEmpty
                ? Center(
                    child: Text(
                      'Coming soon',
                      style: TextStyle(
                        fontSize: 13 * scale,
                        fontWeight: FontWeight.w800,
                        color: Colors.white38,
                      ),
                    ),
                  )
                : Padding(
                    padding: EdgeInsets.fromLTRB(
                      12 * scale,
                      4 * scale,
                      12 * scale,
                      12 * scale,
                    ),
                    child: GridView.builder(
                      physics: const BouncingScrollPhysics(),
                      gridDelegate:
                          SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 5,
                            crossAxisSpacing: 10 * scale,
                            mainAxisSpacing: 10 * scale,
                            childAspectRatio: 0.80,
                          ),
                      itemCount: list.length,
                      itemBuilder: (_, i) {
                        final c = list[i];
                        final sel = c.name == selected;
                        return _SlotCard(
                          character: c,
                          selected: sel,
                          fallbackSeed: i,
                          onTap: () => onTap(c.name),
                        );
                      },
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

class _SlotCard extends StatelessWidget {
  const _SlotCard({
    required this.character,
    required this.selected,
    required this.fallbackSeed,
    required this.onTap,
  });

  final roster.GameCharacter character;
  final bool selected;
  final int fallbackSeed;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = selected
        ? GameColors.gold
        : ShowcasePalette.forSeed(fallbackSeed);
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Expanded(
            child: LayoutBuilder(
              builder: (context, box) {
                return Stack(
                  children: [
                    CharacterCardPanel(
                      character: character.name,
                      color: color,
                      width: box.maxWidth,
                      aspectRatio: box.maxWidth / box.maxHeight,
                      dark: selected,
                      glow: selected ? GameColors.gold : null,
                      fallbackSeed: fallbackSeed,
                      cornerRadius: 10,
                    ),
                    if (selected)
                      Positioned(
                        right: 4,
                        top: 4,
                        child: Container(
                          padding: const EdgeInsets.all(2.5),
                          decoration: const BoxDecoration(
                            color: GameColors.gold,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            Icons.check,
                            size: 12,
                            color: Color(0xFF231708),
                          ),
                        ),
                      ),
                  ],
                );
              },
            ),
          ),
          const SizedBox(height: 3),
          Text(
            character.name,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 9.5,
              fontWeight: FontWeight.w800,
              color: selected ? GameColors.gold : Colors.white70,
            ),
          ),
        ],
      ),
    );
  }
}

// =============================================================================
// RIGHT ZONE — "Characters" category sidebar: red close (X) button up top,
// then 7 stacked tab pills (Gaming / Anime / Donghua / Marvels / K-pop /
// Politicians / Banner). Selected tab = gold treatment, unselected = flat
// light panel, exactly per the reference screenshot.
// =============================================================================
class _CategorySidebar extends StatelessWidget {
  const _CategorySidebar({
    required this.category,
    required this.scale,
    required this.onSelect,
    required this.onClose,
  });

  final roster.CharacterCategory category;
  final double scale;
  final ValueChanged<roster.CharacterCategory> onSelect;
  final VoidCallback onClose;

  static const _tabs = <(roster.CharacterCategory, String)>[
    (roster.CharacterCategory.gaming, 'Gaming'),
    (roster.CharacterCategory.anime, 'Anime'),
    (roster.CharacterCategory.donghua, 'Donghua'),
    (roster.CharacterCategory.marvels, 'Marvels'),
    (roster.CharacterCategory.kpop, 'K-pop'),
    (roster.CharacterCategory.politicians, 'Politicians'),
    (roster.CharacterCategory.banner, 'Banner'),
  ];

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(6 * scale, 10 * scale, 10 * scale, 10 * scale),
      child: Column(
        children: [
          Align(
            alignment: Alignment.topRight,
            child: GestureDetector(
              onTap: onClose,
              child: Container(
                width: 34 * scale,
                height: 34 * scale,
                decoration: BoxDecoration(
                  color: const Color(0xFFFF1824),
                  shape: BoxShape.circle,
                  boxShadow: GameShadows.button,
                ),
                child: Icon(Icons.close, color: Colors.white, size: 18 * scale),
              ),
            ),
          ),
          SizedBox(height: 14 * scale),
          Text(
            'Characters',
            style: TextStyle(
              fontSize: 13 * scale,
              fontWeight: FontWeight.w900,
              color: Colors.white70,
              letterSpacing: 0.4,
            ),
          ),
          SizedBox(height: 10 * scale),
          Expanded(
            child: ListView.separated(
              physics: const BouncingScrollPhysics(),
              itemCount: _tabs.length,
              separatorBuilder: (_, __) => SizedBox(height: 8 * scale),
              itemBuilder: (_, i) {
                final (cat, label) = _tabs[i];
                final sel = cat == category;
                return GestureDetector(
                  onTap: () => onSelect(cat),
                  behavior: HitTestBehavior.opaque,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 160),
                    padding: EdgeInsets.symmetric(vertical: 11 * scale),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      gradient: sel
                          ? const LinearGradient(
                              colors: [Color(0xFFF0B232), Color(0xFFE5A932)],
                            )
                          : const LinearGradient(
                              colors: [Color(0xFFE5EBEE), Color(0xFFDCE2E6)],
                            ),
                      borderRadius: BorderRadius.circular(12 * scale),
                      boxShadow: sel
                          ? [
                              BoxShadow(
                                color: GameColors.gold.withValues(alpha: 0.55),
                                blurRadius: 10,
                                spreadRadius: 0.5,
                              ),
                            ]
                          : null,
                    ),
                    child: Text(
                      label,
                      textAlign: TextAlign.center,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 11 * scale,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.2,
                        color: sel
                            ? const Color(0xFF231708)
                            : const Color(0xFF2B3440),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
